import express from 'express'; 
import morgan from 'morgan'; 
import cors from 'cors'; 
import path from 'path';

const app = express();

//Conexion a base de datos

const mongoose = require('mongoose');
const options = {useNewUrlParser: true, useUnifiedTopology: true};

const uri = 'mongodb+srv://root:admin@cluster0.ozuup.mongodb.net/prueba'

mongoose.connect(uri,options).then(
    () => {
        console.log('conexion a DB')
    },
    err => { console.log(err) }
);
//middleware

app.use(morgan('tiny'));
app.use(cors());
app.use(express.json()); 



//application/x-www-form-urlencoded 
app.use(express.urlencoded({ extended: true }))



// Middleware para Vue.js router modo history 
const history = require('connect-history-api-fallback'); 
app.use(history()); 
app.use(express.static(path.join(__dirname, 'public')));



//Rutas

app.use('/api', require('./routes/paciente'));

//puerto

app.set('puerto', process.env.PORT || 3000); 
app.listen(app.get('puerto'), function () { 
    console.log('Se esta escuchando en el puerto '+ app.get('puerto')); 
});