<template>
    <nav id="barra1" class="ml-23">
        <a href="/contenido">Contenido</a>
        <a href="/historial">Consultar Historial paciente</a>
        <a href="/registro">Registrar paciente</a>
        <a href="/calcular">Calcular IMC</a>
        
    </nav>
</template>


<style>
#barra1{
    background-color: rgb(168, 199, 235);
    padding: 20px;
}

#barra1 a{
    color: rgb(23, 23, 156);
    margin-left: 12px;
    text-decoration: aquamarine;
}
</style>