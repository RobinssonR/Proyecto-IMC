<template>
    
    <footer class="footer-section">


                      <img class="bd-placeholder-img rounded-circle" src="../assets/equipo.jpg">
                      <h2>Robinsson Rosero</h2>
                      <p>Administrador de Empresas y desarrollador web.</p>
                      <p><a class="btn btn-primary" href="https://www.linkedin.com/login/">Ver más</a></p>
                <article>
                    <h2>Contacto</h2>
                        <p>Correo electrónico: desarrollador@gmail.com</p>
                        <p>Whatsapp 377 777 7777</p>
                        </article>
                        
    </footer>
</template>

<style>

.footer-section {
    color: rgb(19, 13, 112);
    margin-left: 200px;
    margin-top: 200px;
}

.img {
    width: 200px;
    height: 200px;
}

</style>


