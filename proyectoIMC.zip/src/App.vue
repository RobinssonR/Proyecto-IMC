<template>
  <v-app>

    <Header/>
    <Barra/>

    <v-main>
      <router-view/>
    </v-main>
    <Footer/>
  </v-app>
</template>

<script>

import Header from './components/Header.vue'
import Barra from './components/Barra.vue'
import Footer from './components/Footer.vue'

export default {
  name: 'App',

  components: {
    Header,
    Barra,
    Footer,
  },


  data: () => ({
    //
  }),
};
</script>
