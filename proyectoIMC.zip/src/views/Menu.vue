<template>

    <div>
        <center>

            <img src="../assets/alimentacion2.jpg" alt="25" srcset="">

        </center>

    </div>

</template>


<style>

.img{
    height: 300px;
    margin-top: 100px;
    margin: 52px;

}

</style>