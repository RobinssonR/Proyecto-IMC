<template>
  <Menu/>
</template>

<script>
  import Menu from './Menu.vue'

  export default {
    name: 'Home',

    components: {
      Menu,
    },
  }
</script>
