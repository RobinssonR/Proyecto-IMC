import express from "express";
const router = express.Router();

import Paciente from "../models/pacientes";

//agregar un paciente

router.post('/paciente-nuevo',async(req,res)=>{
    const body=req.body;

    try{

        const pacienteDB=await Paciente.create(body);
        res.status(200).json(pacienteDB)

    }catch (error){
        return res.status(500).json({
            mensaje: 'ocurrio un error',
            error
        })

    }
});

module.exports = router;
