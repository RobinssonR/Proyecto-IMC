import Mongoose from "mongoose";
const Schema = Mongoose.Schema;

const pacienteSchema = new Schema ({

    nombre: {type:String, required: [true,'Nombre obligatorio']},
    numeroDocumento: {type:String, required: [true,'documento obligatorio']},
    fechaNacimiento: {type: Date, required: [true,'Fecha obligatoria']},
    direccion: String,
    telefono: String,
    correoelectronico: String,
    eps: String,
    info: String,

})

//convertir a modelo
const Paciente = Mongoose.model('Paciente',pacienteSchema);
export default Paciente;